package com.whyzvr.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Service foreground yang menampilkan crosshair mengambang di atas aplikasi lain. */
class CrosshairService : Service() {

    companion object {
        const val ACTION_STOP = "com.whyzvr.crosshair.STOP"
        private const val CHANNEL_ID = "crosshair_channel"
        private const val NOTIF_ID = 1

        fun start(context: Context) {
            val i = Intent(context, CrosshairService::class.java)
            context.startForegroundService(i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, CrosshairService::class.java))
        }
    }

    private lateinit var windowManager: WindowManager
    private var crosshairView: CrosshairView? = null
    private var params: WindowManager.LayoutParams? = null

    // Simpan sebagai properti agar tidak di-garbage-collect
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        applySettings()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        createNotificationChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        addOverlay()
        Prefs.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        Prefs.setEnabled(this, true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Layar diputar: hitung ulang posisi
        applySettings()
    }

    override fun onDestroy() {
        Prefs.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        crosshairView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        crosshairView = null
        Prefs.setEnabled(this, false)
        super.onDestroy()
    }

    private fun addOverlay() {
        val view = CrosshairView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        params = lp
        crosshairView = view
        windowManager.addView(view, lp)
        applySettings()
    }

    /** Terapkan ukuran & posisi dari pengaturan ke overlay. */
    private fun applySettings() {
        val view = crosshairView ?: return
        val lp = params ?: return

        val dm = resources.displayMetrics
        val sizePx = (Prefs.getSize(this) * dm.density).toInt().coerceAtLeast(1)
        val xPercent = Prefs.getX(this)
        val yPercent = Prefs.getY(this)

        lp.width = sizePx
        lp.height = sizePx
        lp.x = ((dm.widthPixels - sizePx) * xPercent / 100f).toInt()
        lp.y = ((dm.heightPixels - sizePx) * yPercent / 100f).toInt()

        try {
            windowManager.updateViewLayout(view, lp)
            view.invalidate()
        } catch (_: Exception) {
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, CrosshairService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .setOngoing(true)
            .build()
    }
}
