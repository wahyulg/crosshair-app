package com.whyzvr.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** View yang menggambar crosshair (tanda plus + titik tengah) dengan outline hitam agar terlihat di background terang maupun gelap. */
class CrosshairView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 255, 0)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
    }
    private val dotOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 255, 0)
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        val half = minOf(w, h) / 2f

        // Ketebalan garis mengikuti ukuran, minimal 1.5dp
        val stroke = maxOf(1.5f * density, minOf(w, h) / 25f)
        val outline = stroke + 2f * density
        val gap = half * 0.15f
        val pad = outline / 2f

        outlinePaint.strokeWidth = outline
        linePaint.strokeWidth = stroke

        // Garis atas, bawah, kiri, kanan (dengan celah di tengah)
        val segments = arrayOf(
            floatArrayOf(cx, pad, cx, cy - gap),
            floatArrayOf(cx, cy + gap, cx, h - pad),
            floatArrayOf(pad, cy, cx - gap, cy),
            floatArrayOf(cx + gap, cy, w - pad, cy)
        )
        for (s in segments) canvas.drawLine(s[0], s[1], s[2], s[3], outlinePaint)
        for (s in segments) canvas.drawLine(s[0], s[1], s[2], s[3], linePaint)

        // Titik tengah
        val dotR = stroke * 0.9f
        canvas.drawCircle(cx, cy, dotR + 1.5f * density, dotOutline)
        canvas.drawCircle(cx, cy, dotR, dotPaint)
    }
}
