package com.whyzvr.crosshair

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggle: Button
    private lateinit var seekSize: SeekBar
    private lateinit var seekX: SeekBar
    private lateinit var seekY: SeekBar
    private lateinit var txtSize: TextView
    private lateinit var txtX: TextView
    private lateinit var txtY: TextView

    private val notifPermission =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {
            // Notifikasi ditolak pun overlay tetap jalan, jadi lanjut saja
            startOverlay()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggle = findViewById(R.id.btnToggle)
        seekSize = findViewById(R.id.seekSize)
        seekX = findViewById(R.id.seekX)
        seekY = findViewById(R.id.seekY)
        txtSize = findViewById(R.id.txtSize)
        txtX = findViewById(R.id.txtX)
        txtY = findViewById(R.id.txtY)

        seekSize.max = Prefs.SIZE_MAX - Prefs.SIZE_MIN
        seekX.max = 100
        seekY.max = 100

        loadValues()

        seekSize.setOnSeekBarChangeListener(listener { p ->
            val v = p + Prefs.SIZE_MIN
            Prefs.setSize(this, v)
            txtSize.text = getString(R.string.label_size, v)
        })
        seekX.setOnSeekBarChangeListener(listener { p ->
            Prefs.setX(this, p)
            txtX.text = getString(R.string.label_x, p)
        })
        seekY.setOnSeekBarChangeListener(listener { p ->
            Prefs.setY(this, p)
            txtY.text = getString(R.string.label_y, p)
        })

        btnToggle.setOnClickListener {
            if (Prefs.isEnabled(this)) {
                CrosshairService.stop(this)
                btnToggle.text = getString(R.string.btn_start)
            } else {
                requestStart()
            }
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            Prefs.reset(this)
            loadValues()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButton()
    }

    private fun loadValues() {
        val size = Prefs.getSize(this)
        val x = Prefs.getX(this)
        val y = Prefs.getY(this)
        seekSize.progress = size - Prefs.SIZE_MIN
        seekX.progress = x
        seekY.progress = y
        txtSize.text = getString(R.string.label_size, size)
        txtX.text = getString(R.string.label_x, x)
        txtY.text = getString(R.string.label_y, y)
    }

    private fun refreshButton() {
        btnToggle.text = getString(
            if (Prefs.isEnabled(this)) R.string.btn_stop else R.string.btn_start
        )
    }

    private fun requestStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlay()
        }
    }

    private fun startOverlay() {
        CrosshairService.start(this)
        btnToggle.text = getString(R.string.btn_stop)
    }

    private fun listener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }

        override fun onStartTrackingTouch(seekBar: SeekBar) {}
        override fun onStopTrackingTouch(seekBar: SeekBar) {}
    }
}
