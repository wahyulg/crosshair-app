package com.whyzvr.crosshair

import android.content.Context
import android.content.SharedPreferences

/** Penyimpanan pengaturan crosshair. */
object Prefs {
    private const val NAME = "crosshair_prefs"
    private const val KEY_SIZE = "size_dp"
    private const val KEY_X = "pos_x_percent"
    private const val KEY_Y = "pos_y_percent"
    private const val KEY_ENABLED = "enabled"

    const val SIZE_MIN = 10
    const val SIZE_MAX = 300
    const val SIZE_DEFAULT = 40
    const val POS_DEFAULT = 50

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getSize(c: Context) = prefs(c).getInt(KEY_SIZE, SIZE_DEFAULT)
    fun getX(c: Context) = prefs(c).getInt(KEY_X, POS_DEFAULT)
    fun getY(c: Context) = prefs(c).getInt(KEY_Y, POS_DEFAULT)
    fun isEnabled(c: Context) = prefs(c).getBoolean(KEY_ENABLED, false)

    fun setSize(c: Context, v: Int) = prefs(c).edit().putInt(KEY_SIZE, v).apply()
    fun setX(c: Context, v: Int) = prefs(c).edit().putInt(KEY_X, v).apply()
    fun setY(c: Context, v: Int) = prefs(c).edit().putInt(KEY_Y, v).apply()
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun reset(c: Context) {
        prefs(c).edit()
            .putInt(KEY_SIZE, SIZE_DEFAULT)
            .putInt(KEY_X, POS_DEFAULT)
            .putInt(KEY_Y, POS_DEFAULT)
            .apply()
    }
}
