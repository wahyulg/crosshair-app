# Floating Crosshair (Android)

Aplikasi crosshair mengambang di atas semua aplikasi. Ukuran dan posisinya bisa diatur langsung (real-time).

## Cara build

1. Install **Android Studio** (di Linux Mint bisa lewat Snap/Flatpak atau unduh dari developer.android.com).
2. Buka Android Studio, pilih **Open**, lalu pilih folder `crosshair-app` ini.
3. Tunggu Gradle sync selesai (butuh internet; JDK 17 bawaan Android Studio sudah cukup).
4. Sambungkan HP Android (aktifkan **Opsi pengembang > Debugging USB**), lalu klik tombol **Run**.
   Atau buat APK: menu **Build > Build APK(s)**, hasilnya di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara pakai

1. Buka aplikasi, tekan **Aktifkan Crosshair**.
2. Pertama kali, akan diminta izin **Tampilkan di atas aplikasi lain** — aktifkan, lalu kembali dan tekan tombol lagi.
3. Atur slider **Ukuran**, **Posisi horizontal**, **Posisi vertikal**. Crosshair langsung bergerak.
4. Untuk mematikan: tombol di aplikasi, atau tombol **Matikan** di notifikasi.

## Struktur kode

- `CrosshairService.kt` : service foreground + overlay (WindowManager)
- `CrosshairView.kt` : menggambar crosshair
- `MainActivity.kt` : layar pengaturan
- `Prefs.kt` : penyimpanan pengaturan

Overlay dibuat tidak bisa disentuh (touch tembus ke aplikasi di bawahnya).
